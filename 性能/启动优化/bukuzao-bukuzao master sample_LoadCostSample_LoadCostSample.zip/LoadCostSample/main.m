//
//  main.m
//  LoadCostSample
//
//  Created by everettjf on 2018/8/18.
//  Copyright © 2018 everettjf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

FOUNDATION_IMPORT void LoadRulerPrintLoadCostsInfo();


int main(int argc, char * argv[]) {
    LoadRulerPrintLoadCostsInfo();
    
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
