//
//  ServiceTwo.m
//  LoadMethod
//
//  Created by WengHengcong on 2018/3/8.
//  Copyright © 2018年 LuCi. All rights reserved.
//

#import "ServiceTwo.h"

@implementation ServiceTwo

@end
