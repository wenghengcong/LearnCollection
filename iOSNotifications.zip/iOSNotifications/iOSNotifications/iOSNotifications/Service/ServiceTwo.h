//
//  ServiceTwo.h
//  LoadMethod
//
//  Created by WengHengcong on 2018/3/8.
//  Copyright © 2018年 LuCi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ServiceTwo : NSObject

@end
