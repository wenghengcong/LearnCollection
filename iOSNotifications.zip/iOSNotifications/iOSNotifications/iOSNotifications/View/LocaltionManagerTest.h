//
//  LocaltionManagerTest.h
//  iOSNotifications
//
//  Created by WengHengcong on 2017/3/20.
//  Copyright © 2017年 WengHengcong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LocaltionManagerTest : NSObject

- (void)checkLocaltionEnable;

@end
