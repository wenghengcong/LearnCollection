//
//  PushHandle.m
//  iOSNotifications
//
//  Created by WengHengcong on 2018/3/8.
//  Copyright © 2018年 WengHengcong. All rights reserved.
//

#import "JSMessageServiceBase.h"

@implementation JSMessageServiceBase

- (void)jsMessageOpenServiceWithUserinfo:(NSDictionary *)userinfo
{
    
}

@end
