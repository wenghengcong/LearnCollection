//
//  JSNotification.m
//  iOSNotifications
//
//  Created by WengHengcong on 2016/12/26.
//  Copyright © 2016年 WengHengcong. All rights reserved.
//

#import "JSNotification.h"

@implementation JSNotification

@end
