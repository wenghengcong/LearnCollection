//
//  BFPerson.m
//  Category
//
//  Created by WengHengcong on 2018/11/27.
//  Copyright © 2018 WengHengcong. All rights reserved.
//

#import "BFPerson.h"

@implementation BFPerson

- (void)test
{
    NSLog(@"-[BFPerson test]");
}
@end
